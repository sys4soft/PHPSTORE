<div class="container-fluid">
    <div class="row mt-3">
        
        <div class="col-md-2">
            <?php include(__DIR__ . '/layouts/admin_menu.php')?>
        </div>

        <div class="col-md-10">
            <h3>Lista de clientes</h3>
            <hr>

            <?php if(count($clientes) == 0): ?>
                <p class="text-center text-muted">Não existem cliente registados.</p>
            <?php else: ?>
                <!-- apresenta a tabela de clientes -->
                <table class="table table-sm" id="tabela-clientes">
                    <thead class="table-dark">
                        <tr>
                            <th>Nome</th>
                            <th>Email</th>
                            <th>Morada</th>
                            <th>Cidade</th>
                            <th>Telefone</th>
                            <!-- ativo / inativo -->
                            <th>Ativo</th>
                            <!-- created_at -->
                            <th>Registado em</th>
                            <!-- deleted_at -->
                            <th>Eliminado</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php foreach($clientes as $cliente): ?>
                            <tr>
                                <td><?= $cliente->nome_completo ?></td>
                                <td><?= $cliente->email ?></td>
                                <td><?= $cliente->morada ?></td>
                                <td><?= $cliente->cidade ?></td>
                                <td><?= $cliente->telefone ?></td>
                                <td><?= $cliente->activo ?></td>
                                <td><?= $cliente->created_at ?></td>
                                <td><?= $cliente->deleted_at ?></td>
                            </tr>
                        <?php endforeach;?>

                    </tbody>
                </table>
            <?php endif; ?>

        </div>

    </div>
</div>

<script>
    $(document).ready(function() {
        $('#tabela-clientes').DataTable({
            language: {
                "decimal": "",
                "emptyTable": "No data available in table",
                "info": "Mostrando página _PAGE_ de um total de _PAGES_",
                "infoEmpty": "Não existem encomendas disponíveis",
                "infoFiltered": "(Filtrado de um total de _MAX_ encomendas)",
                "infoPostFix": "",
                "thousands": ",",
                "lengthMenu": "Apresenta _MENU_ encomendas por página",
                "loadingRecords": "Carregando...",
                "processing": "Processando...",
                "search": "Procurar:",
                "zeroRecords": "Não foram encontradas encomendas",
                "paginate": {
                    "first": "Primeira",
                    "last": "Última",
                    "next": "Seguinte",
                    "previous": "Anterior"
                },
                "aria": {
                    "sortAscending": ": ativar para ordenar a coluna de forma ascendente",
                    "sortDescending": ": ativar para ordenar a coluna de forma descendente"
                }
            }
        });
    });
</script>