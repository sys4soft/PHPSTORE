<?php

namespace core\controllers;

use core\classes\Database;
use core\classes\EnviarEmail;
use core\classes\Store;

class admin
{
    // ===========================================================
    public function index()
    {
        echo 'Backoffice da loja!';
    }

    // ===========================================================
    public function lista_clientes()
    {
        echo 'Lista de clientes!';
    }
}