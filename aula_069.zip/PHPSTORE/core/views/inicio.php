<div class="container-fluid">
    <div class="row">
        <div class="col-12">

        <h1>Página inicial da loja</h1>

        </div>
    </div>
</div>