<div>
    <div class="mb-3">
        <a href="?a=inicio">Início</a>
    </div>

    <div class="mb-3">
        <a href="?a=lista_clientes">Clientes</a>
    </div>

    <div class="mb-3">
        <a href="?a=lista_encomendas">Encomendas</a>
    </div>
</div>