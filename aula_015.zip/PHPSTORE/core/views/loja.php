<div class="container-fluid">
    <div class="row">
        <div class="col-12">
        
        <h3>LOJA!</h3>
        
        </div>
    </div>
</div>