<div class="container-fluid">
    <div class="row my-3">
        <div class="col text-center">
            <a href="" class="btn btn-primary mx-3"><i class="fas fa-edit"></i> Alterar dados pessoais</a>
            <a href="" class="btn btn-primary mx-3"><i class="fas fa-key"></i> Alterar a password</a>
            <a href="" class="btn btn-primary mx-3"><i class="far fa-list-alt"></i> Histórico de encomendas</a>
        </div>
    </div>
</div>