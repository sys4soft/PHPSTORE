<?php

namespace core\models;

use core\classes\Database;
use core\classes\Store;

class Encomendas
{
    // ================================================================
    public function guardar_encomenda($dados_encomenda, $produtos){

        /* 
        - dados da encomenda
        - dados dos produtos da encomenda
        */

    }
}