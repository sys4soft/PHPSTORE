<h3>Carrinho!</h3>
<a href="?a=limpar_carrinho" class="btn btn-sm btn-primary">Limpar carrinho</a>
<pre>
<?php print_r($_SESSION); ?>
</pre>