<div class="container-fluid">
    <div class="row">
        <div class="col-12">

        <h3 class="text-center">Histórico de encomendas</h3>

        <?php if(count($historico_encomendas) == 0): ?>
            <p class="text-center">Não existem encomendas registadas.</p>
        <?php else:?>

            <table>
            </table>
            <p>Total: 0</p>
            
        <?php endif;?>
        </div>
    </div>
</div>