<?php

namespace core\controllers;

use core\classes\Database;
use core\classes\EnviarEmail;
use core\classes\Store;

class admin
{
    // ===========================================================
    public function index()
    {

        

        Store::Layout_admin([
            'admin/layouts/html_header',
            'admin/layouts/header',
            'admin/home',
            'admin/layouts/footer',
            'admin/layouts/html_footer',
        ]);
    }

    // ===========================================================
    public function lista_clientes()
    {
        echo 'Lista de clientes!';
    }
}