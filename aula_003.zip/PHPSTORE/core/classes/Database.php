<?php

namespace core\classes;

class Database{

    public function __construct()
    {
        echo 'Base de dados!';
    }

}