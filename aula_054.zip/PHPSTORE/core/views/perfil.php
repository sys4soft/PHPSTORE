<div>Dados do perfil</div>

<pre>
<?php
print_r($dados_cliente);
?>