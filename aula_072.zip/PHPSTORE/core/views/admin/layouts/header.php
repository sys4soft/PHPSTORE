<?php 
use core\classes\Store;
?>
<div class="container-fluid navegacao">
    <div class="row">
        <div class="col-6 p-3">
            Nav
        </div>
    </div>
</div>