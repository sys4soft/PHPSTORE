<h3>Carrinho!</h3>

<pre>
<?php print_r($_SESSION); ?>
</pre>