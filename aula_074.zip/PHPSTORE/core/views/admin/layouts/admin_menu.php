<div>
    <div class="mb-3">
        <a href="?a=inicio">Início</a>
    </div>

    <div class="mb-3">
        <a href="?a=clientes">Clientes</a>
    </div>

    <div class="mb-3">
        <a href="?a=encomendas">Encomendas</a>
    </div>
</div>