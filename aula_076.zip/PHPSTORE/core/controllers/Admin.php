<?php

namespace core\controllers;

use core\classes\Database;
use core\classes\EnviarEmail;
use core\classes\Store;
use core\models\AdminModel;

class admin
{
    // ===========================================================
    // usuário admin: admin@admin.com
    // senha:         123456
    // ===========================================================
    public function index()
    {
        // verifica se já existe sessão aberta (admin)
        if (!Store::adminLogado()) {
            Store::redirect('admin_login', true);
            return;
        }

        // verificar se existem encomendas em estado PENDENTE
        $ADMIN = new AdminModel();
        $total_encomendas_pendentes = $ADMIN->total_encomendas_pendentes();
        $total_encomendas_em_processamento = $ADMIN->total_encomendas_em_processamento();


        $data = [
            'total_encomendas_pendentes' => $total_encomendas_pendentes,
            'total_encomendas_em_processamento' => $total_encomendas_em_processamento
        ];
        
        // já existe um admin logado
        Store::Layout_admin([
            'admin/layouts/html_header',
            'admin/layouts/header',
            'admin/lista_encomendas',
            'admin/layouts/footer',
            'admin/layouts/html_footer',
        ], $data);
    }

    // ===========================================================
    public function admin_login(){
        
        if (Store::adminLogado()) {
            Store::redirect('inicio', true);
            return;
        }

        // apresenta o quadro de login
        Store::Layout_admin([
            'admin/layouts/html_header',
            'admin/layouts/header',
            'admin/login_frm',
            'admin/layouts/footer',
            'admin/layouts/html_footer',
        ]);
    }

    // ===========================================================
    public function admin_login_submit()
    {
        // verifica se já existe um utilizador logado
        if (Store::adminLogado()) {
            Store::redirect('inicio', true);
            return;
        }

        // verifica se foi efetuado o post do formulário de login do admin
        if ($_SERVER['REQUEST_METHOD'] != 'POST') {
            Store::redirect('inicio', true);
            return;
        }

        // validar se os campos vieram corretamente preenchidos
        if (
            !isset($_POST['text_admin']) ||
            !isset($_POST['text_senha']) ||
            !filter_var(trim($_POST['text_admin']), FILTER_VALIDATE_EMAIL)
        ) {
            // erro de preenchimento do formulário
            $_SESSION['erro'] = 'Login inválido';
            Store::redirect('admin_login', true);
            return;
        }

        // prepara os dados para o model
        $admin = trim(strtolower($_POST['text_admin']));
        $senha = trim($_POST['text_senha']);

        // carrega o model e verifica se login é válido
        $admin_model = new AdminModel();
        $resultado = $admin_model->validar_login($admin, $senha);

        // analisa o resultado
        if(is_bool($resultado)){
         
            // login inválido
            $_SESSION['erro'] = 'Login inválido';
            Store::redirect('login', true);
            return;

        } else {

            // login válido. Coloca os dados na sessão do admin
            $_SESSION['admin'] = $resultado->id_admin;
            $_SESSION['admin_usuario'] = $resultado->usuario;

            // redirecionar para a página inicial do backoffice
            Store::redirect('inicio', true);
        }

    }

    // ===========================================================
    public function admin_logout(){

        // faz o logout do admin da sessão
        unset($_SESSION['admin']);
        unset($_SESSION['admin_usuario']);

        // redirecionar para o início
        Store::redirect('inicio', true);
    }





    // ===========================================================
    public function lista_clientes()
    {
        echo 'Lista de clientes!';
    }


    // ===========================================================
    public function lista_encomendas(){

        // apresenta a lista de encomendas (usando filtro se for o caso)

        // verifica se existe um filtro da query string
        $filtro = '';
        if(isset($_GET['f'])){
            $filtro = $_GET['f'];
        }

        $data = [];

        // apresenta a página das encomendas
        Store::Layout_admin([
            'admin/layouts/html_header',
            'admin/layouts/header',
            'admin/home',
            'admin/layouts/footer',
            'admin/layouts/html_footer',
        ], $data);

    }
}