<?php

define('APP_NAME',          'PHPSTORE');
define('APP_VERSION',       '1.0.0');

define('BASE_URL',          'http://localhost/PHPSTORE/public/');

// MYSQL
define('MYSQL_SERVER',      'localhost');
define('MYSQL_DATABASE',    'php_store');
define('MYSQL_USER',        'user_php_store');
define('MYSQL_PASS',        'H6gefoD4Bo7E');
define('MYSQL_CHARSET',     'utf8');

// mail
require_once('../../email_config.php');
// define('EMAIL_HOST',        'smtp.gmail.com');
// define('EMAIL_FROM',        'sys4soft.phpstore@gmail.com');
// define('EMAIL_PASS',        '0123!PhpStore');
// define('EMAIL_PORT',        587);