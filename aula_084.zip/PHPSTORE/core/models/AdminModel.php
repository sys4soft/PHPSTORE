<?php

namespace core\models;

use core\classes\Database;
use core\classes\Store;

class AdminModel
{

    // ===========================================================
    public function validar_login($usuario_admin, $senha)
    {

        // verificar se o login é válido
        $parametros = [
            ':usuario_admin' => $usuario_admin
        ];

        $bd = new Database();
        $resultados = $bd->select("
            SELECT * FROM admins 
            WHERE usuario = :usuario_admin 
            AND deleted_at IS NULL
        ", $parametros);

        if (count($resultados) != 1) {
            // não existe usuário admin
            return false;
        } else {

            // temos usuário admin. Vamos ver a sua password
            $usuario_admin = $resultados[0];

            // verificar a password
            if (!password_verify($senha, $usuario_admin->senha)) {
                
                // password inválida
                return false;

            } else {

                // login válido
                return $usuario_admin;
            }
        }
    }

    // ===========================================================
    // CLIENTES
    // ===========================================================
    public function lista_clientes()
    {
        // vai buscar todos os clientes registados na base de dados
        $bd = new Database();
        $resultados = $bd->select("
            SELECT id_cliente,email,nome_completo,telefone,activo,deleted_at
            FROM clientes
        ");
        return $resultados;
    }

    // ===========================================================
    // ENCOMENDAS
    // ===========================================================
    public function total_encomendas_pendentes(){

        // vai buscar a quantidade de encomendas pendentes
        $bd = new Database();
        $resultados = $bd->select("
            SELECT COUNT(*) total FROM encomendas
            WHERE status = 'PENDENTE'
        ");
        return $resultados[0]->total;
    }

    // ===========================================================
    public function total_encomendas_em_processamento(){
        
        // vai buscar a quantidade de encomendas em processamento
        $bd = new Database();
        $resultados = $bd->select("
            SELECT COUNT(*) total FROM encomendas
            WHERE status = 'Em PROCESSAMENTO'
        ");
        return $resultados[0]->total;
    }

    // ===========================================================
    public function lista_encomendas($filtro){
        $bd = new Database();
        $sql = "SELECT e.*, c.nome_completo FROM encomendas e LEFT JOIN clientes c ON e.id_cliente = c.id_cliente";
        if($filtro != ''){
            $sql .= " WHERE e.status = '$filtro'";
        }
        $sql .= ' ORDER BY e.id_encomenda DESC';
        return $bd->select($sql);
    } 
}