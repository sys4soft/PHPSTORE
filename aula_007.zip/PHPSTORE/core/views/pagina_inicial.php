<h1><?= $titulo ?></h1>

<ul>
<?php foreach($clientes as $cliente):?>
    <li><?= $cliente ?></li>
<?php endforeach;?>
</ul>