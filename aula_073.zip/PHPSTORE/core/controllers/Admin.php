<?php

namespace core\controllers;

use core\classes\Database;
use core\classes\EnviarEmail;
use core\classes\Store;
use core\models\AdminModel;

class admin
{
    // ===========================================================
    // usuário admin: admin@admin.com
    // senha:         123456
    // ===========================================================
    public function index()
    {
        // verifica se já existe sessão aberta (admin)
        if (!Store::adminLogado()) {
            Store::redirect('admin_login', true);
            return;
        }
        
        // já existe um admin logado
        Store::Layout_admin([
            'admin/layouts/html_header',
            'admin/layouts/header',
            'admin/home',
            'admin/layouts/footer',
            'admin/layouts/html_footer',
        ]);
    }

    // ===========================================================
    public function admin_login(){
        
        if (Store::adminLogado()) {
            Store::redirect('inicio', true);
            return;
        }

        // apresenta o quadro de login
        Store::Layout_admin([
            'admin/layouts/html_header',
            'admin/layouts/header',
            'admin/login_frm',
            'admin/layouts/footer',
            'admin/layouts/html_footer',
        ]);
    }

    // ===========================================================
    public function admin_login_submit()
    {
        // verifica se já existe um utilizador logado
        if (Store::adminLogado()) {
            Store::redirect('inicio', true);
            return;
        }

        // verifica se foi efetuado o post do formulário de login do admin
        if ($_SERVER['REQUEST_METHOD'] != 'POST') {
            Store::redirect('inicio', true);
            return;
        }

        // validar se os campos vieram corretamente preenchidos
        if (
            !isset($_POST['text_admin']) ||
            !isset($_POST['text_senha']) ||
            !filter_var(trim($_POST['text_admin']), FILTER_VALIDATE_EMAIL)
        ) {
            // erro de preenchimento do formulário
            $_SESSION['erro'] = 'Login inválido';
            Store::redirect('admin_login', true);
            return;
        }

        // prepara os dados para o model
        $admin = trim(strtolower($_POST['text_admin']));
        $senha = trim($_POST['text_senha']);

        // carrega o model e verifica se login é válido
        $admin_model = new AdminModel();
        $resultado = $admin_model->validar_login($admin, $senha);

        // analisa o resultado
        if(is_bool($resultado)){
         
            // login inválido
            $_SESSION['erro'] = 'Login inválido';
            Store::redirect('login', true);
            return;

        } else {

            // login válido. Coloca os dados na sessão do admin
            $_SESSION['admin'] = $resultado->id_admin;
            $_SESSION['admin_usuario'] = $resultado->usuario;

            // redirecionar para a página inicial do backoffice
            Store::redirect('inicio', true);
        }

    }

    // ===========================================================
    public function lista_clientes()
    {
        echo 'Lista de clientes!';
    }
}