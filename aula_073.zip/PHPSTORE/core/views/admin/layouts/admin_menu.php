<div>
    <div class="mb-3">
        <a href="#">Início</a>
    </div>

    <div class="mb-3">
        <a href="#">Clientes</a>
    </div>

    <div class="mb-3">
        <a href="#">Encomendas</a>
    </div>
</div>