<?php

namespace core\models;

use core\classes\Database;
use core\classes\Store;

class AdminModel
{

    // ===========================================================
    public function validar_login($usuario_admin, $senha)
    {

        // verificar se o login é válido
        $parametros = [
            ':usuario_admin' => $usuario_admin
        ];

        $bd = new Database();
        $resultados = $bd->select("
            SELECT * FROM admins 
            WHERE usuario = :usuario_admin 
            AND deleted_at IS NULL
        ", $parametros);

        if (count($resultados) != 1) {
            // não existe usuário admin
            return false;
        } else {

            // temos usuário admin. Vamos ver a sua password
            $usuario_admin = $resultados[0];

            // verificar a password
            if (!password_verify($senha, $usuario_admin->senha)) {
                
                // password inválida
                return false;

            } else {

                // login válido
                return $usuario_admin;
            }
        }
    }

    // ===========================================================
    public function total_encomendas_pendentes(){

        // vai buscar a quantidade de encomendas pendentes
        $bd = new Database();
        $resultados = $bd->select("
            SELECT COUNT(*) total FROM encomendas
            WHERE status = 'PENDENTE'
        ");
        return $resultados[0]->total;
    }

    // ===========================================================
    public function total_encomendas_em_processamento(){
        
        // vai buscar a quantidade de encomendas em processamento
        $bd = new Database();
        $resultados = $bd->select("
            SELECT COUNT(*) total FROM encomendas
            WHERE status = 'Em PROCESSAMENTO'
        ");
        return $resultados[0]->total;
    }

    // ===========================================================
    public function lista_encomendas($filtro){

        // vai buscar a lista de encomendas com filtro

        $bd = new Database();

        $sql = 'SELECT encomendas.*, clientes.nome_completo FROM encomendas, clientes WHERE 1';

        if($filtro != ''){
            $sql .= " AND encomendas.status = '$filtro'";
        }

        $sql .= ' AND clientes.id_cliente = encomendas.id_cliente ORDER BY encomendas.id_encomenda DESC';


        die($sql);

        return $bd->select($sql);
    }    
}