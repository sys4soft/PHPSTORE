<div class="container-fluid">
    <div class="row">
        <div class="col-12">

        <h1 class="text-center">Detalhe da encomenda</h1>

        <!-- dados da encomenda -->

        <!-- lista de produtos da encomenda -->

        </div>
    </div>
</div>