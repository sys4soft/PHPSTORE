<?php

namespace core\controllers;

use core\classes\Database;
use core\classes\EnviarEmail;
use core\classes\Store;

class admin
{
    // ===========================================================
    public function index()
    {

        // verifica se já existe sessão aberta (admin)
        if (!Store::adminLogado()) {
            Store::redirect('admin_login', true);
            return;
        }
        
        // já existe um admin logado
        Store::Layout_admin([
            'admin/layouts/html_header',
            'admin/layouts/header',
            'admin/home',
            'admin/layouts/footer',
            'admin/layouts/html_footer',
        ]);
    }

    // ===========================================================
    public function admin_login(){
        
        if (Store::adminLogado()) {
            Store::redirect('inicio', true);
            return;
        }

        // apresenta o quadro de login
        Store::Layout_admin([
            'admin/layouts/html_header',
            'admin/layouts/header',
            'admin/login_frm',
            'admin/layouts/footer',
            'admin/layouts/html_footer',
        ]);
    }

    // ===========================================================
    public function lista_clientes()
    {
        echo 'Lista de clientes!';
    }
}