<?php

namespace core\controladores;

class Loja{

    public function carrinho(){
        echo 'Carrinho!!!!';
    }

}