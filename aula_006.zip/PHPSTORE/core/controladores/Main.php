<?php

namespace core\controladores;

class Main{

    public function index(){
        echo 'Inicio!!!!!!';
    }

    public function loja(){
        echo 'Loja!!!!!!';
    }

}