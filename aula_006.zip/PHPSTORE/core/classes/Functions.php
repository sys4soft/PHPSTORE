<?php

namespace core\classes;

class Functions{

    public function teste(){
        echo 'olá';
    }

}