<div class="container-fluid">
    <div class="row">
        <div class="col-12 text-center p-3">
            <?= APP_NAME .'('.APP_VERSION.') &copy; ' . date('Y')?>
        </div>
    </div>
</div>