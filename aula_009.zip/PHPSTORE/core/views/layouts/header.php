<div class="container-fluid">
    <div class="row">
        <div class="col-6 p-3"><?= APP_NAME ?></div>
        <div class="col-6 text-end p-3">
            <a href="">Item 1</a>
            <a href="">Item 2</a>
            <a href="">Item 3</a>
            <a href=""><i class="fas fa-shopping-cart"></i></a>
            <span class="badge bg-warning">10</span>
        </div>
    </div>
</div>